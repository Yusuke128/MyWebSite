<?php
/**
 * @author      Wployalty (Alagesan)
 * @license     http://www.gnu.org/licenses/gpl-3.0.html
 * @link        https://www.wployalty.net
 * */
defined( 'ABSPATH' ) or die;
?>
<!--<div id="wlr-main"></div>-->
<div id="wlr-main">
    <div id="wlr_pre_loading" class="wlr_pre_loading">
        <div class="wlr wlrf-loading wlr_loading"></div>
    </div>
</div>

<!-- <div id="wp-loyalty-admin-container"></div> -->